import java.sql.PreparedStatement;
import java.util.Scanner;

public class tictactoe {
    private boolean play = true;
    private Scanner sc = new Scanner(System.in);
    private char palyer_move = 'c';
    private char computer_move;
    private byte size = 3;
    private char board[][] = new char[size][size];;
    private byte row;
    private byte column;
    private int input;
    private int id;
    private int i = 1;

    public tictactoe() {
        System.out.println("-------------- Welcome Tic Tac Toe Game --------------\n ");
    }

    public void play_game(int id) throws Exception {
        this.id = id;

        int choice = 1;
        palyer_move = first_turn();
        computer_move = (palyer_move == 'X') ? 'O' : 'X';
        while (choice == 1) {
            input();
            play = true;
            displayboard();
            while (play) {
                if (i == 1) {
                    i = 2;
                    palyer_move();

                } else if (i == 2) {
                    i = 1;
                    computer_move();

                }
                displayboard();
            }
            System.out.println("1.play game \n2. exit");
            System.out.print("ENTER CHOICE :- ");
            choice = sc.nextInt();
        }
    }

    private char first_turn() {
        while (palyer_move != 'X' && palyer_move != 'O' && palyer_move != 'x' && palyer_move != 'o') {
            System.out.println("\n");
            System.out.print("WHO IS FIRST TURN 'X' OR 'O' :-  ");
            palyer_move = sc.nextLine().charAt(0);
            if (palyer_move == 'X' || palyer_move == 'x') {
                palyer_move = 'X';
                break;
            } else if (palyer_move == 'O' || palyer_move == 'o') {
                palyer_move = 'O';
                break;
            } else {
                System.out.println("Enter Valid Input ");
            }
        }
        return palyer_move;

    }

    private void palyer_move() throws Exception {
        System.out.print("ENTER NUMBER : ");
        input = sc.nextInt();
        if (valid_turn(input)) {
            board[row][column] = palyer_move;
            gameover(palyer_move);
            return;
        } else {
            System.out.println("ENTER VALID INPUT");
            palyer_move();
        }
    }

    private void computer_move() throws Exception {
        System.out.print("COMPUTER THIKING");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(".");
                Thread.sleep(300);
            }
            System.out.print("\b\b\b\b\b");
            System.out.print("     ");
            System.out.print("\b\b\b\b\b");
        }
        System.out.print("\r                        \r");
        while (!(valid_turn(input))) {
            input = (int) (Math.random() * 10);
        }
        board[row][column] = computer_move;
        gameover(computer_move);
    }

    private void input() {
        char a = '1';
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                board[i][j] = a;
                a++;
            }
        }
    }

    private void displayboard() throws Exception {
        System.out.println("===================");
        for (int i = 0; i < size; i++) {
            System.out.print("| ");
            for (int j = 0; j < size; j++) {
                Thread.sleep(100);
                System.out.print(" ");
                if (board[i][j] == computer_move) {
                    System.out.print("\033[0;31m" + board[i][j] + "\033[0m");
                    System.out.print(" ");
                } else if (board[i][j] == palyer_move) {
                    System.out.print("\033[0;32m" + board[i][j] + "\033[0m");
                    System.out.print(" ");
                } else {
                    System.out.print("\033[0;30m" + board[i][j] + "\033[0m");
                    System.out.print(" ");
                }
                System.out.print(" | ");
            }
            System.out.println();
            System.out.println("===================");
        }
    }

    private boolean valid_turn(int input) {
        switch (input) {
            case 1:
                row = 0;
                column = 0;
                break;
            case 2:
                row = 0;
                column = 1;
                break;
            case 3:
                row = 0;
                column = 2;
                break;
            case 4:
                row = 1;
                column = 0;
                break;
            case 5:
                row = 1;
                column = 1;
                break;
            case 6:
                row = 1;
                column = 2;
                break;
            case 7:
                row = 2;
                column = 0;
                break;
            case 8:
                row = 2;
                column = 1;
                break;
            case 9:
                row = 2;
                column = 2;
                break;

            default:
                break;
        }
        return board[row][column] <= '9';
    }

    private boolean checkGamedrow() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (board[i][j] <= '9') {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean checkWin(char curentplayer) {
        for (int i = 0; i < 3; i++) {
            if (board[i][0] == curentplayer && board[i][1] == curentplayer && board[i][2] == curentplayer) {
                return true;
            }
            if (board[0][i] == curentplayer && board[1][i] == curentplayer && board[2][i] == curentplayer) {
                return true;
            }
        }
        if (board[0][0] == curentplayer && board[1][1] == curentplayer && board[2][2] == curentplayer) {
            return true;
        }
        if (board[0][2] == curentplayer && board[1][1] == curentplayer && board[2][0] == curentplayer) {
            return true;
        }
        return false;
    }

    private void gameover(char curentplayer) throws Exception {
        PreparedStatement pst = driver.con.prepareStatement(driver.insert_Tic);
        pst.setInt(1, id);
        pst.setString(2, String.valueOf(palyer_move));
        pst.setString(3, String.valueOf(computer_move));
        if (checkWin(curentplayer)) {
            if (curentplayer == computer_move) {
                System.out.println("\033[0;31m" + "COMPUTER WIN" + "\033[0m");
                pst.setString(4, "LOSE");
                i = 2;
            } else {
                System.out.println("\033[0;32m" + "YOU WIN" + "\033[0m");
                pst.setString(4, "WIN");
                i = 1;
            }
            play = false;
            pst.executeUpdate();
        } else if (checkGamedrow()) {
            System.out.println(" Match is draw ");
            pst.setString(4, "TIE");
            pst.executeUpdate();
            play = false;
        }
    }

}

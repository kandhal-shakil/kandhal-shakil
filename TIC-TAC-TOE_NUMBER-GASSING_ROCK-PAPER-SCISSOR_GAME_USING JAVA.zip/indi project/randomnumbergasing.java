import java.sql.*;
import java.util.Scanner;

class randomnumber {
    int attempt = 1;
    int randomnumber;
    Scanner sc = new Scanner(System.in);
    String name = "";
    int guess;

    randomnumber() {
        System.out.println("=============== Welcome Guess Randome Number Game ===============  \n \n ");
    }

    void guasenumber(int id) throws Exception {
        int choice = 0;
        PreparedStatement pst;
        while (choice != 2) {
            System.out.print("1. PLAY GAME\n2. EXIT \nEnter Your Choice :- ");
            pst = driver.con.prepareStatement(driver.insert_random);
            choice = sc.nextInt();
            if (choice == 1) {
                randomnumber = (int) (Math.random() * 100);
                System.out.print(" Enter Number 1 To 100 :- ");
                guess = sc.nextInt();
                while (randomnumber != guess) {
                    if (guess < randomnumber) {
                        System.out.println(" it's low ");
                        attempt++;
                        System.out.print(" Enter Number 1 To 100 :- ");
                        guess = sc.nextInt();
                    } else if (guess > randomnumber) {
                        System.out.println(" it's high");
                        attempt++;
                        System.out.print(" Enter Number 1 To 100 :- ");
                        guess = sc.nextInt();
                    }
                }
                if (randomnumber == guess) {
                    System.out.println("Congratulations! You've guessed the number in " + attempt + " attempts.");
                    pst.setInt(1, id);
                    pst.setInt(2, randomnumber);
                    pst.setInt(3, attempt);
                    pst.executeUpdate();
                }
            }
        }
    }
}
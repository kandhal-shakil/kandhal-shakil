import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

class driver {
    static String inert_user = "INSERT INTO USER VALUES (? , ? , ? , ? )";
    static String select_user = "SELECT ID FROM USER WHERE ID = ?";

    static String insert_random = "INSERT INTO random_nubmer VALUES (? , ? , ?)";
    static String select_random = "SELECT * FROM random_nubmer WHERE ID = ?";

    static String insert_rock = "INSERT INTO rockpaper VALUES (? , ? , ? , ?)";
    static String select_rock = "SELECT * FROM rockpaper WHERE ID = ? ";

    static String insert_Tic = "INSERT INTO tictactoe VALUES (? , ? , ? , ? )";
    static String select_tic = "SELECT * FROM tictactoe WHERE ID = ? ";

    static String select_all = "SELECT * FROM USER";
    static Connection con;
    static Statement st;

    driver() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/game", "root", "");
        st = con.createStatement();
    }
}
import java.sql.*;
import java.util.*;

class rokpaperscissors {
    String[] optin = { "rock", "paper", "scissors" };
    int choice = 0;
    String computerchoice;
    Scanner sc = new Scanner(System.in);
    String name;
    int id;
    PreparedStatement pst;

    rokpaperscissors(int id) throws Exception {
        this.id = id;
        System.out.println("=============== Welcome Rack Paper Scissors Game =============== \n \n ");
        while (true) {
            pst = driver.con.prepareStatement(driver.insert_rock);
            pst.setInt(1, id);
            System.out.print(" 1. rock \n 2.paper \n 3.scissors \n 4.Exit \n Enter Your Choice :- ");
            choice = sc.nextInt();
            if (choice == 4) {
                System.out.println("=============== Thanks For Play Rock Paper Scissors Game ===============");
                break;
            }
            computerchoice = optin[new Random().nextInt(3)];
            pst.setString(2, optin[(choice - 1)].toUpperCase());
            pst.setString(3, computerchoice.toUpperCase());
            String[] arr = { "_", "\\", "/" };
            System.out.print("WAIT FOR RESULT ");
            int j = 0;
            for (int i = 0; i < 15; i++) {
                System.out.print(arr[j]);
                Thread.sleep(100);
                System.out.print("\b");
                j++;
                if (j == 3)
                    j = 0;
            }
            System.out.print("\r                  \r");
            if (computerchoice.equalsIgnoreCase(optin[(choice - 1)])) {
                System.out.println("\033[0;33m" + " Match is tie !" + "\033[0m");
                pst.setString(4, "TIE");
            } else if (optin[(choice - 1)].equalsIgnoreCase("Rock") && computerchoice.equalsIgnoreCase("Scissors")
                    || optin[(choice - 1)].equalsIgnoreCase("Paper") && computerchoice.equalsIgnoreCase("Rock")
                    || optin[(choice - 1)].equalsIgnoreCase("Scissors") && computerchoice.equalsIgnoreCase("Paper")) {
                System.out.println("\033[0;32m" + "YOU WIN" + "\033[0m");
                pst.setString(4, "WIN");
            } else {
                System.out.println("\033[0;31m" + "YOU LOSE" + "\033[0m");
                pst.setString(4, "LOSE");
            }
            System.out
            .println("COMPUTER CHOICE IS :- " + computerchoice + "\nYOUR CHOICE IS :- " + optin[(choice - 1)]);
            pst.executeUpdate();
        }
    }
}

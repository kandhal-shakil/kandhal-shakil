import java.sql.*;

public class display {
    static PreparedStatement pst;
    static Connection con = driver.con;

    public static void tic(int id, boolean b) throws Exception {
        pst = con.prepareStatement(driver.select_tic);
        pst.setInt(1, id);
        ResultSet rs = pst.executeQuery();
        int i = 0;
        System.out.println("==============================");
        while (rs.next()) {
            i++;
            if (b) {
                tic_racord(rs , i);
            }
        }
        if (!b) {
            int win;
            int lose;
            int tie;
            pst = con.prepareStatement("SELECT COUNT(*) FROM `tictactoe` WHERE ID = ? and RESULT = ? ");
            pst.setInt(1, id);
            pst.setString(2, "WIN");
            rs = pst.executeQuery();
            rs.next();
            win = rs.getInt(1);
            pst = con.prepareStatement("SELECT COUNT(*) FROM `tictactoe` WHERE ID = ? and RESULT = ? ");
            pst.setInt(1, id);
            pst.setString(2, "LOSE");
            rs = pst.executeQuery();
            rs.next();
            lose = rs.getInt(1);
            tie = i - (win + lose);
            System.out.println("TOTEL WIN :- " + win);
            System.out.println("TOTEL LOSE TIME :- " + lose);
            System.out.println("TOTEL MATCH DRAW :- " + tie);
        }
        System.out.println("TOTAL TIC_TAC_TOE " + i + " TIME PLAY");
        System.out.println("==============================\n");
    }

    public static void random(int id) throws Exception {
        pst = con.prepareStatement(driver.select_random);
        pst.setInt(1, id);
        ResultSet rs = pst.executeQuery();
        int i = 0;
        System.out.println("==============================");
        while (rs.next()) {
            System.out.println("------------------------------");
            System.out.println("GAME NUMBER :- " + ++i);
            System.out.println("PLAYER ID :- " + rs.getInt(1));
            System.out.println("ORIGINAL NUMBER :- " + rs.getInt(2));
            System.out.println("TOTAL ATTEMPT :- " + rs.getInt(3));
            System.out.println("------------------------------");
        }
        System.out.println("TOTAL RANDOM NUMBERR GASSING GAME " + i + " TIME PLAY");
        System.out.println("==============================\n");
    }

    public static void rock(int id , boolean b) throws Exception {
        pst = con.prepareStatement(driver.select_rock);
        pst.setInt(1, id);
        ResultSet rs = pst.executeQuery();
        int i = 0;
        System.out.println("==============================");
        while (rs.next()) {
            i++;
            if (b) {
                rock_racord(rs , i);
            }
        }
        if (!b) {
            int win;
            int lose;
            int tie;
            pst = con.prepareStatement("SELECT COUNT(*) FROM `rockpaper` WHERE ID = ? and RESULT = ? ");
            pst.setInt(1, id);
            pst.setString(2, "WIN");
            rs = pst.executeQuery();
            rs.next();
            win = rs.getInt(1);
            pst = con.prepareStatement("SELECT COUNT(*) FROM `rockpaper` WHERE ID = ? and RESULT = ? ");
            pst.setInt(1, id);
            pst.setString(2, "LOSE");
            rs = pst.executeQuery();
            rs.next();
            lose = rs.getInt(1);
            tie = i - (win + lose);
            System.out.println("TOTEL WIN :- " + win);
            System.out.println("TOTEL LOSE TIME :- " + lose);
            System.out.println("TOTEL MATCH DRAW :- " + tie);
        }
        System.out.println("TOTAL ROCK-PAPER-SCISSORS GAME " + i + " TIME PLAY");
        System.out.println("==============================\n");
    }

    private static void tic_racord(ResultSet rs , int i) throws Exception {
        System.out.println("------------------------------");
        System.out.println("GAME NUMBER :- " + i);
        System.out.println("PLAYER ID :- " + rs.getInt(1));
        System.out.println("YOUR MOVE :-" + rs.getString(2));
        System.out.println("COMPUTER MOVE :-" + rs.getString(3));
        System.out.println("RESULT :-" + rs.getString(4));
        System.out.println("------------------------------");
    }

    private static void rock_racord(ResultSet rs , int i) throws Exception {
        System.out.println("------------------------------");
        System.out.println("GAME NUMBER :- " + i);
        System.out.println("PLAYER ID :- " + rs.getInt(1));
        System.out.println("YOUR CHOICE :-" + rs.getString(2));
        System.out.println("COMPUTER CHOICE :-" + rs.getString(3));
        System.out.println("RESULT :-" + rs.getString(4));
        System.out.println("------------------------------");
    }
}
import qrcode;

def generate_qr_code():
    user_link = input("Enter the link to generate a QR code: ")

    qr = qrcode.QRCode(
        version=1,  # Controls the size of the QR Code (1 to 40)
        error_correction=qrcode.constants.ERROR_CORRECT_L,  # Error correction level
        box_size=10, 
        border=4,  # Thickness of the border (minimum is 4)
    )
    qr.add_data(user_link)  # Add the link data to the QR code
    qr.make(fit=True)

    qr_image = qr.make_image(fill_color="black", back_color="white")
    output_file = "user_qr_code.png"
    qr_image.save(output_file)

    print(f"QR code generated and saved as {output_file}.")

if __name__ == "__main__":
    generate_qr_code()

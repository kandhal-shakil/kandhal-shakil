class linkList {
    class node {
        user data;
        node next;

        public node(user data) {
            this.data = data;
            this.next = null;
        }
    }

    node first = null;

    void ADD(user data) {
        node n = new node(data);
        if (first == null) {
            first = n;
        } else {
            node temp = first;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = n;
            n.next = null;
        }
    }

    void DELETE_user(int data) {
        if (first == null) {
            return;
        } else {
            node temp = first;
            while (temp.next != null) {
                if (temp.next.data.getId() == data) {
                    temp.next = temp.next.next;
                } else {
                    temp = temp.next;
                }
            }
        }
    }
}